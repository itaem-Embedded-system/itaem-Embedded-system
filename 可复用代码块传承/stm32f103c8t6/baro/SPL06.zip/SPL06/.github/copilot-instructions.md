# Copilot Repository Instructions (Low-Risk Text Only)

## Scope and Safety Boundary
- This repository uses low-risk text customizations only.
- Do not assume any hook, MCP, or script-based automation is enabled.
- Treat this file and `.github/instructions/*.instructions.md` as guidance text, not executable policy.

## Repository Purpose
- STM32 embedded firmware template project generated from CubeMX HAL framework.
- Primary development flow: edit and reason in VS Code, then run CMake-based configure/build validation.
- Keil is mainly used for board download, debugger setup, and hardware-specific troubleshooting.

## Source Layout (High Level)
- `Core/`: CubeMX-generated startup/system/peripheral init and main entry.
- `app/`: application logic, scheduling, data handling.
- `device/`: device/register protocol logic (hardware-agnostic as much as possible).
- `platform/`: HAL-bound platform adaptation for SPI/I2C/UART/GPIO/delay.
- `middleware/`: reusable protocol/algorithm/logging modules.
- `docs/`: human-readable standards and process documentation.

## Build Facts
- CMake presets: `Debug`, `Release` in `CMakePresets.json`.
- Generator: Ninja.
- Toolchain file is under `cmake/` (prefer `cmake/gcc-arm-none-eabi.cmake`).
- VS Code CMake path is configured in `.vscode/settings.json`.
- User module source files are registered in `CMakeLists.txt`.

## Template Profile (Update Per New Project)
- MCU family/model: update startup file, linker script, and CMSIS device settings.
- Board resources: update GPIO/SPI/I2C/UART mapping and clock assumptions.
- Device set: update `device/` and `platform/` pairing modules.
- Build entry: ensure new `.c` sources are added into `CMakeLists.txt`.
- IDE sync: ensure `MDK-ARM/` project groups still include all active user sources.

## Editing Rules
- Prefer edits in `app/`, `device/`, `platform/`, `middleware/`, and `CMakeLists.txt`.
- In `Core/` generated files, modify only `USER CODE BEGIN/END` regions unless explicitly requested.
- Keep business logic out of generated sections; call into user modules instead.
- If adding a new `.c` file, update `CMakeLists.txt` and remind that Keil project groups may also need manual sync.
- When MCU model changes, treat `Core/`, startup, and linker assets as regeneration targets; do not hand-port generated init blocks unless required.

## Validation Strategy
- Primary validation is configure/build and static inspection.
- Do not assume hardware is connected.
- For flashing and hardware verification issues, escalate to Keil/board workflow.

## References
- Project-level human spec: `docs/嵌软项目结构规范.md`.
- Driver-level human spec: `docs/ic开发规范.md`.
