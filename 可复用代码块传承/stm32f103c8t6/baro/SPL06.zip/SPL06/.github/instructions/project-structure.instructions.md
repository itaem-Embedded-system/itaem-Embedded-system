---
description: "Use when modifying app/device/platform/middleware/CMake files. Enforces layering boundaries and build synchronization for this STM32 project."
applyTo: "app/**/*.c,app/**/*.h,device/**/*.c,device/**/*.h,platform/**/*.c,platform/**/*.h,middleware/**/*.c,middleware/**/*.h,CMakeLists.txt"
---

# Project Structure Rules

- `app/` owns business flow and runtime behavior.
- `device/` owns register protocol and device semantics.
- `platform/` owns HAL binding and board resource operations.
- `middleware/` owns reusable protocol/algorithm/logging functions.

- Do not call HAL APIs directly from `device/`.
- Do not place register-level manipulation in `app/`.
- Do not place business policy in `platform/`.
- When new source files are added, update `CMakeLists.txt`.
- Remind user that Keil project file grouping may also require manual updates.
- Keep module naming device-agnostic where practical (for example, generic bus/service interfaces in `platform/`, chip-specific logic in `device/`).
- When replacing a sensor/IC, prefer adding a new `device/<chip>.c` plus minimal `platform` adapter changes instead of rewriting `app/` flow.
