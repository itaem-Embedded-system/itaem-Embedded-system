/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "baro.h"
#include "vofa.h"
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

VOFA_HandleTypeDef hvofa;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

bool UART_SendCallback(void *handle, const uint8_t *data, uint16_t len);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  // 锁定为已验证可用的 SPI Mode0
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  (void)HAL_SPI_Init(&hspi1);

  Baro_Init();

  // 初始化 VOFA
  VOFA_Init(&hvofa, &huart2, UART_SendCallback, VOFA_FMT_JUSTFLOAT, VOFA_BAUD_115200);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    static uint32_t lastSentTick = 0;
    Baro_Run();

    // 由 app 层统一采样和容错，main 仅做数据回传
    Baro_Data_t baroData;
    if (Baro_GetLatestData(&baroData) && baroData.tick_ms != lastSentTick) {
        float data[4] = {baroData.temperature, baroData.pressure, baroData.altitude, (float)baroData.tick_ms};
        VOFA_Data_TypeDef_Enum types[4] = {VOFA_DATA_FLOAT, VOFA_DATA_FLOAT, VOFA_DATA_FLOAT, VOFA_DATA_FLOAT};
        VOFA_SendData(&hvofa, data, 4, types);
        lastSentTick = baroData.tick_ms;
    }

    HAL_Delay(10);  // 每 10ms 发送一次
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

// 串口发送回调函数
bool UART_SendCallback(void *handle, const uint8_t *data, uint16_t len) {
    UART_HandleTypeDef* huart = (UART_HandleTypeDef*)handle;
    return HAL_UART_Transmit(huart, data, len, 100) == HAL_OK;
}

// 应用层延时函数实现
void App_DelayMs(uint32_t ms)
{
    HAL_Delay(ms);
}

uint32_t App_GetTickMs(void)
{
    return HAL_GetTick();
}

// 仅实现 JustFloat 发送逻辑，避免链接 vofa.c
static const uint8_t VOFA_JUSTFLOAT_TAIL[4] = {0x00, 0x00, 0x80, 0x7F};

void VOFA_Init(VOFA_HandleTypeDef *hvofa,
               void *serial_handle,
               VOFA_SerialSendFunc send_cb,
               VOFA_FormatEnum init_fmt,
               VOFA_BaudRateEnum init_baud)
{
    if (hvofa == NULL) return;
    hvofa->serial_handle = serial_handle;
    hvofa->send_callback = send_cb;
    hvofa->fmt = init_fmt;
    hvofa->baud = init_baud;
    hvofa->rx_read_idx = 0;
    hvofa->rx_write_idx = 0;
    hvofa->rx_overflow_cnt = 0;
    hvofa->rx_total_bytes = 0;
    hvofa->frame_len = 0;
    hvofa->frame_count = 0;
    hvofa->new_frame_flag = false;
    hvofa->is_processing = false;
}

bool VOFA_SendData(VOFA_HandleTypeDef *hvofa,
                   void *data,
                   uint8_t ch_cnt,
                   VOFA_Data_TypeDef_Enum *data_types)
{
    if (hvofa == NULL || data == NULL || ch_cnt == 0 || data_types == NULL) {
        return false;
    }
    if (hvofa->send_callback == NULL) return false;

    // 仅支持最多 16 通道
    if (ch_cnt > 16) return false;

    switch (hvofa->fmt) {
    case VOFA_FMT_FIREFIREWATER: {
      uint8_t send_buf[256] = {0};
      uint16_t send_len = 0;
      for (uint8_t i = 0; i < ch_cnt; i++) {
        int written = 0;
        switch (data_types[i]) {
        case VOFA_DATA_INT:
          written = snprintf((char *)send_buf + send_len, sizeof(send_buf) - send_len, "%ld", (long)((int32_t *)data)[i]);
          break;
        case VOFA_DATA_UINT:
          written = snprintf((char *)send_buf + send_len, sizeof(send_buf) - send_len, "%lu", (unsigned long)((uint32_t *)data)[i]);
          break;
        case VOFA_DATA_FLOAT:
          written = snprintf((char *)send_buf + send_len, sizeof(send_buf) - send_len, "%.3f", (double)((float *)data)[i]);
          break;
        case VOFA_DATA_CHAR:
          written = snprintf((char *)send_buf + send_len, sizeof(send_buf) - send_len, "%d", (int)((int8_t *)data)[i]);
          break;
        case VOFA_DATA_UCHAR:
          written = snprintf((char *)send_buf + send_len, sizeof(send_buf) - send_len, "%u", (unsigned int)((uint8_t *)data)[i]);
          break;
        case VOFA_DATA_SHORT:
          written = snprintf((char *)send_buf + send_len, sizeof(send_buf) - send_len, "%d", (int)((int16_t *)data)[i]);
          break;
        case VOFA_DATA_USHORT:
          written = snprintf((char *)send_buf + send_len, sizeof(send_buf) - send_len, "%u", (unsigned int)((uint16_t *)data)[i]);
          break;
        default:
          return false;
        }

        if (written <= 0 || (uint16_t)written >= (uint16_t)(sizeof(send_buf) - send_len)) {
          return false;
        }

        send_len += (uint16_t)written;
        if (i < (uint8_t)(ch_cnt - 1)) {
          if (send_len >= sizeof(send_buf) - 2U) {
            return false;
          }
          send_buf[send_len++] = ',';
        }
      }

      if (send_len >= sizeof(send_buf) - 2U) {
        return false;
      }
      send_buf[send_len++] = '\r';
      send_buf[send_len++] = '\n';
      return hvofa->send_callback(hvofa->serial_handle, send_buf, send_len);
    }

    case VOFA_FMT_JUSTFLOAT: {
      float float_buf[16];
      for (uint8_t i = 0; i < ch_cnt; i++) {
        switch (data_types[i]) {
        case VOFA_DATA_INT:    float_buf[i] = (float)((int32_t*)data)[i];   break;
        case VOFA_DATA_UINT:   float_buf[i] = (float)((uint32_t*)data)[i];  break;
        case VOFA_DATA_FLOAT:  float_buf[i] = ((float*)data)[i];            break;
        case VOFA_DATA_CHAR:   float_buf[i] = (float)((int8_t*)data)[i];    break;
        case VOFA_DATA_UCHAR:  float_buf[i] = (float)((uint8_t*)data)[i];   break;
        case VOFA_DATA_SHORT:  float_buf[i] = (float)((int16_t*)data)[i];   break;
        case VOFA_DATA_USHORT: float_buf[i] = (float)((uint16_t*)data)[i];  break;
        default: return false;
        }
      }

      if (!hvofa->send_callback(hvofa->serial_handle,
                    (uint8_t*)float_buf,
                    (uint16_t)(ch_cnt * sizeof(float)))) {
        return false;
      }

      return hvofa->send_callback(hvofa->serial_handle,
                    VOFA_JUSTFLOAT_TAIL,
                    sizeof(VOFA_JUSTFLOAT_TAIL));
    }

    case VOFA_FMT_RAWDATA: {
      uint8_t send_buf[128] = {0};
      uint16_t send_len = 0;
      for (uint8_t i = 0; i < ch_cnt; i++) {
        switch (data_types[i]) {
        case VOFA_DATA_INT:
          if (send_len + sizeof(int32_t) > sizeof(send_buf)) return false;
          memcpy(&send_buf[send_len], &((int32_t *)data)[i], sizeof(int32_t));
          send_len += sizeof(int32_t);
          break;
        case VOFA_DATA_UINT:
          if (send_len + sizeof(uint32_t) > sizeof(send_buf)) return false;
          memcpy(&send_buf[send_len], &((uint32_t *)data)[i], sizeof(uint32_t));
          send_len += sizeof(uint32_t);
          break;
        case VOFA_DATA_FLOAT:
          if (send_len + sizeof(float) > sizeof(send_buf)) return false;
          memcpy(&send_buf[send_len], &((float *)data)[i], sizeof(float));
          send_len += sizeof(float);
          break;
        case VOFA_DATA_CHAR:
          if (send_len + sizeof(int8_t) > sizeof(send_buf)) return false;
          memcpy(&send_buf[send_len], &((int8_t *)data)[i], sizeof(int8_t));
          send_len += sizeof(int8_t);
          break;
        case VOFA_DATA_UCHAR:
          if (send_len + sizeof(uint8_t) > sizeof(send_buf)) return false;
          memcpy(&send_buf[send_len], &((uint8_t *)data)[i], sizeof(uint8_t));
          send_len += sizeof(uint8_t);
          break;
        case VOFA_DATA_SHORT:
          if (send_len + sizeof(int16_t) > sizeof(send_buf)) return false;
          memcpy(&send_buf[send_len], &((int16_t *)data)[i], sizeof(int16_t));
          send_len += sizeof(int16_t);
          break;
        case VOFA_DATA_USHORT:
          if (send_len + sizeof(uint16_t) > sizeof(send_buf)) return false;
          memcpy(&send_buf[send_len], &((uint16_t *)data)[i], sizeof(uint16_t));
          send_len += sizeof(uint16_t);
          break;
        default:
          return false;
        }
      }
      return hvofa->send_callback(hvofa->serial_handle, send_buf, send_len);
    }

    default:
      return false;
    }
}

/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM4 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM4)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
