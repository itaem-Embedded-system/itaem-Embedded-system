# Copilot Repository Instructions (Low-Risk Text Only)

## Scope and Safety Boundary
- This repository uses low-risk text customizations only.
- Do not assume any hook, MCP, or script-based automation is enabled.
- Treat this file and `.github/instructions/*.instructions.md` as guidance text, not executable policy.

## Repository Purpose
- STM32 embedded firmware template project generated from CubeMX HAL framework.
- Primary development flow: edit and reason in VS Code, then run CMake-based configure/build validation.
- Keil is an optional future extension path for board download, debugger setup, and hardware-specific troubleshooting.

## Source Layout (High Level)
- `Core/`: CubeMX-generated startup/system/peripheral init and main entry.
- `app/`: application logic, scheduling, data handling.
- `device/`: device/register protocol logic (hardware-agnostic as much as possible).
- `platform/`: HAL-bound platform adaptation for SPI/I2C/UART/GPIO/delay.
- `middleware/`: reusable protocol/algorithm/logging modules.
- `docs/`: human-readable standards and process documentation.

## Build Facts
- CMake presets: `Debug`, `Release` in `CMakePresets.json`.
- Generator: Ninja.
- Toolchain file is under `cmake/` (prefer `cmake/gcc-arm-none-eabi.cmake`).
- User module source files are registered in the root `CMakeLists.txt`.
- CubeMX-generated sources and generated build entries live under `cmake/stm32cubemx/CMakeLists.txt` and should normally be updated by regeneration, not ad-hoc edits.

## Template Profile (Update Per New Project)
- MCU family/model: update startup file, linker script, and CMSIS device settings.
- Board resources: update GPIO/SPI/I2C/UART mapping and clock assumptions.
- Device set: update `device/` and `platform/` pairing modules.
- Build entry: ensure new user `.c` sources are added into the root `CMakeLists.txt`; keep generated source lists aligned with `cmake/stm32cubemx/CMakeLists.txt` via CubeMX regeneration when practical.
- IDE sync: if `MDK-ARM/` is introduced later, ensure its project groups still include all active user sources.

## Editing Rules
- Prefer edits in `app/`, `device/`, `platform/`, `middleware/`, and the root `CMakeLists.txt`.
- In `Core/` generated files, modify only `USER CODE BEGIN/END` regions unless explicitly requested.
- Keep business logic out of generated sections; call into user modules instead.
- If adding a new user `.c` file, update the root `CMakeLists.txt`; if `MDK-ARM/` is maintained later, sync its project groups as well.
- Treat `cmake/stm32cubemx/CMakeLists.txt`, startup files, linker scripts, and `MDK-ARM/` metadata as regeneration-sensitive assets; only edit them when the task is explicitly about migration, toolchain sync, or chip/board changes.
- When MCU model changes, treat `Core/`, startup, and linker assets as regeneration targets; do not hand-port generated init blocks unless required.

## AI Start Rules
- For non-trivial tasks, read `docs/嵌软开发规范.md` first; if the task touches register logic, init sequencing, parsing, or recovery, also read `docs/ic开发规范.md` before editing.
- Start by locating the correct layer (`app/`, `device/`, `platform/`, `middleware/`, `Core/`) and keep changes inside that boundary.
- Before writing hardware facts such as register defaults, timing waits, protocol extra bits, power-state behavior, or board wiring assumptions, search the repository docs and current code to confirm them.
- If those facts are still unclear after searching, ask the user or explicitly mark them as pending confirmation; do not guess and write them as settled facts.
- For new-engineering or large refactors, propose the split (`device/platform/app` or equivalent) and validation steps first, then make small verifiable edits.
- Treat repository instructions as context reducers, not as a substitute for build results, datasheets, or validated project docs.

## Validation Strategy
- Primary validation is configure/build and static inspection.
- Do not assume hardware is connected.
- If `MDK-ARM/` is introduced later, flashing and hardware verification issues can escalate to the Keil/board workflow.

## References
- Project-level human spec: `docs/嵌软开发规范.md`.
- Driver-level human spec: `docs/ic开发规范.md`.
